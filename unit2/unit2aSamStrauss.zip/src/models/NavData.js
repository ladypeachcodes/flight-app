const NavData =  [
    {"url": "/", "text": "Home", "active": true},
    {"url": "/about", "text": "About", "active": false},
    {"url": "/flights", "text": "Flight List", "active": false},
    {"url": "/add", "text": "Add Flight", "active": false}
  ]

  export default NavData;